# 配合 kind 部署 Kubernetes 的 Registry 仓库及 UI 搭建

### 1.文件说明

1.1 `config.yml`: 用于映射到 Registry 容器中作为启动配置文件。

1.2 `docker-compose-registry.yaml`: 用于启动 Registry 容器和 UI 的配置文件。

1.3 `kind-cluster.yaml`: 用于汲取 Registry 容器内容镜像的 Kind 部署节点集群的配置文件。

1.4 `configMap.yaml`: 用于向 kube-public 声明内部私有镜像拉取地址的配置文件。

1.5 `create.sh`: **只用于一键部署从零到可直接执行部署服务的环境**

1.6 `clean.sh`: **慎用，只用于一键清除所有环境，包括 `Registry` 私有仓库及UI以及模拟集群**



### 2.步骤说明(可参见`create.sh`)

1. 首先建立 Registry 容器，采用 `registry:2` 的版本，映射本地的 `config.yml` 到容器内
`/etc/docker/registry/config.yml` 作为启动配置文件，然后挂载容器卷持久化外界Push的镜像，
固定为 `127.0.0.1:5000` 的端口映射。

2. 通过 `Kind` 建立模拟集群，通过 `--config` 指定配置文件为 `kind-cluster.yaml`，通过 `
--name` 指定集群名称。(在 `kind-cluster.yaml` 配置文件中，指定创建了1个主节点和3个工作节点)

3. 通过 `docker network connect kind registry-service || true` 建立集群网络和 `registry-service`
私有镜像仓库的联系。

4. 通过 `kubectl apply -f configMap.yaml` 向 kube-public 命名空间声明内部私有镜像拉取地址。

5. 通过 `kubectl cluster-info --context kind-(name)` 将 kubectl 的上下文环境转为建立的模拟集群。

6. 通过 `curl -L https://istio.io/downloadIstio | ISTIO_VERSION=1.9.0 TARGET_ARCH=x86_64 sh -` 下载 `istio`。

7. 进入 `istio-1.9.0` 目录下通过 `export PATH=$PWD/bin:$PATH` 命令将 `istioctl` 执行加入全局路径。

8. `istioctl install -y` 下载 `istio`必备组件。

9. 在需要进行 `SideBar` 注入的命名空间下注入 Label `istio-injection: enabled` 以获得自动注入功能。
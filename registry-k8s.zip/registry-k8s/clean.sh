#!/bin/sh

#docker-compose -f docker-compose-registry.yaml down

kind delete cluster --name "$1"

#docker image prune -f
docker container prune -f
docker volume prune -f
docker network prune -f

rm -rf istio-1.9.0/
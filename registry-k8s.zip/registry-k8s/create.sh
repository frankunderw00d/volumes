#!/bin/sh

running="$(docker container inspect -f '{{.State.Running}}' registry-service 2>/dev/null || true)"
if [ "${running}" != 'true' ]; then
    docker-compose -f docker-compose-registry.yaml up -d
fi

kind create cluster --config kind-cluster.yaml --name "$1"

docker network connect kind registry-service || true

kubectl apply -f configMap.yaml

kubectl cluster-info --context kind-"$1"

curl -L https://istio.io/downloadIstio | ISTIO_VERSION=1.9.0 TARGET_ARCH=x86_64 sh -

export PATH=$PWD/istio-1.9.0/bin:$PATH

istioctl install -y

## 启动
#kubectl apply -f web.yaml
#kubectl apply -f web-gateway.yaml

# 对外释放
export INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].nodePort}')
export SECURE_INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="https")].nodePort}')
export INGRESS_HOST=$(kubectl get po -l istio=ingressgateway -n istio-system -o jsonpath='{.items[0].status.hostIP}')
export GATEWAY_URL=$INGRESS_HOST:$INGRESS_PORT
echo "$GATEWAY_URL"